<?php

    $user=$_POST['username'];
    $pwd=$_POST['password'];
    include '../dbconfig.php';
  
    $sql="select library_id from library where librarian_name='$user' and lib_password='$pwd'";
    $result= mysqli_query($conn,$sql);
    $row=  mysqli_fetch_array($result,MYSQLI_ASSOC);

    if($row['library_id']>0)
    {
            $eid=$row['library_id'];
            echo $eid;
    }
    else
    {
            echo "invalid";
    }
?>

