<?php
	
    $bookname=$_POST['bookname'];
   
    include '../dbconfig.php';
		$sql="select * from book where book_name LIKE '%$bookname%' ";
		$result= mysqli_query($conn,$sql);
		if ($result->num_rows > 0) 
		{                                
			while($row = $result->fetch_assoc()) 
			{
				$book_name=$row['book_name'];
				$book_author=$row['book_author'];
				$book_publisher=$row['book_publisher'];
				$book_section=$row['book_section'];
				$book_row=$row['book_row'];
				$book_col=$row['book_col'];
				$book_description=$row['book_description'];
				$max=$row['max_copies'];
				$nocopies=$row['no_of_copies'];
				$status=$row['book_status'];
				
				if($nocopies>0)
				{
					$msg="Book Avaliable";
					echo $book_name."-".$book_author."-".$book_publisher."-".$book_description."-".$book_section."-".$book_row."-".$book_col."-".$nocopies."-".$max."-".$msg."%";
				}
				else
				{
					$msg="Book Not Avaliable";
					echo $book_name."-".$book_author."-".$book_publisher."-".$book_description."-".$book_section."-".$book_row."-".$book_col."-".$nocopies."-".$max."-".$msg."%";
				}
			}
		}
?>

