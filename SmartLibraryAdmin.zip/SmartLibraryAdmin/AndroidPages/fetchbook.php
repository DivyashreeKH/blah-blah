<?php

    $bookid=$_POST['bookid'];

    include '../dbconfig.php';
  
    $sql="select * from book where book_id='$bookid'";
    $result= mysqli_query($conn,$sql);
    $row=  mysqli_fetch_array($result,MYSQLI_ASSOC);
    $book_name=$row['book_name'];
    $book_author=$row['book_author'];
    $book_publisher=$row['book_publisher'];
    $book_section=$row['book_section'];
    $book_row=$row['book_row'];
    $book_col=$row['book_col'];
    $book_description=$row['book_description'];
    $max=$row['max_copies'];
    $nocopies=$row['no_of_copies'];
    
    echo $book_name."-".$book_author."-".$book_publisher."-".$book_description."-".$book_section."-".$book_row."-".$book_col."-".$nocopies;
?>

