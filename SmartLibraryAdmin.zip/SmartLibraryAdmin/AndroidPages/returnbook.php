<?php

    $borid=$_POST['borrowid'];
	
    include '../dbconfig.php';
                $sql3="Select book_id from borrow where borrow_id='$borid'";
		$result3= mysqli_query($conn,$sql3);
		$row3=  mysqli_fetch_array($result3,MYSQLI_ASSOC);
		$bookid=$row3['book_id'];
		$sql="delete from borrow where borrow_id='$borid'";
		$result= mysqli_query($conn,$sql);
		if($result==1)
		{
			$sql1="Select no_of_copies from book where book_id='$bookid'";
			$result1= mysqli_query($conn,$sql1);
			$row1=  mysqli_fetch_array($result1,MYSQLI_ASSOC);
			$nocopies=$row1['no_of_copies'];
				
			$total_copies=$nocopies+1;
			$sql2="update book set `no_of_copies`='$total_copies',`book_status`='0' where book_id='$bookid'";
			$result2= mysqli_query($conn,$sql2);
			if($result2==1)
			{
				echo "Book returned successfully";
			}
			else
			{
				echo "Error";
			}
		}
		else
		{
			echo "Error";
		}
?>

