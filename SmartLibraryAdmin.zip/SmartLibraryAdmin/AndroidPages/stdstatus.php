<?php

    $usn=$_POST['usn'];

    include '../dbconfig.php';
  
		$sql="select * from borrow where student_usn='$usn'";
		$result= mysqli_query($conn,$sql);
		if ($result->num_rows > 0) 
		{                                
			while($row = $result->fetch_assoc()) 
			{
				$bookid=$row['book_id'];
				$sql1="select * from book where book_id='$bookid'";
				$result1= mysqli_query($conn,$sql1);
				$row1=  mysqli_fetch_array($result1,MYSQLI_ASSOC);
				$book_name=$row1['book_name'];
				echo $row['borrow_id']."@".$row['borrow_date']."@".$row['return_date']."@".$book_name."@".$bookid."%";
			}
		}
?>

