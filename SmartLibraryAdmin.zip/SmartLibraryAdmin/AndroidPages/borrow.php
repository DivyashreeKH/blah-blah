<?php
    $bookid=$_POST['bookid'];
	$usn=$_POST['usn'];
	$libid=$_POST['libid'];
	$curdate=$_POST['curdate'];
	$returndate=$_POST['returndate'];
	$stat=$_POST['status'];
	echo $stat;
    include '../dbconfig.php';
	
	if($stat=="Reading")
	{
		$sql1="Select no_of_copies from book where book_id='$bookid'";
		$result1= mysqli_query($conn,$sql1);
		$row1=  mysqli_fetch_array($result1,MYSQLI_ASSOC);
		$nocopies=$row1['no_of_copies'];
			
		$total_copies=$nocopies-1;
		$sql2="update book set no_of_copies='$total_copies',book_status='1' where book_id='$bookid'";
		$result2= mysqli_query($conn,$sql2);
		
		if($result2==1)
		{
			echo "Book is issued for Reading";
		}
		else
		{
			echo "Invalid";
		}
	}
	else
	{
		$sql="INSERT INTO `borrow`(`borrow_id`, `book_id`, `student_usn`, `library_id`, `borrow_date`, `return_date`, `fine_amount`) VALUES 
		('','$bookid','$usn','$libid','$curdate','$returndate','')";
		$result= mysqli_query($conn,$sql);
		if($result==1)
		{
			$sql1="Select no_of_copies from book where book_id='$bookid'";
			$result1= mysqli_query($conn,$sql1);
			$row1=  mysqli_fetch_array($result1,MYSQLI_ASSOC);
			$nocopies=$row1['no_of_copies'];
				
			$total_copies=$nocopies-1;
			
		}
		else
		{
			echo "Invalid";
		}
		$sql2="update book set no_of_copies='$total_copies',book_status='2' where book_id='$bookid'";
		$result2= mysqli_query($conn,$sql2);
		if($result2==1)
		{
			echo "Book Borrowed Successful";
		}
		else
		{
			echo "Invalid";
		}
	}
?>

