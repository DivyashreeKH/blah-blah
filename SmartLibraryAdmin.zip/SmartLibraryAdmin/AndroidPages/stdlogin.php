<?php

    $user=$_POST['username'];
    $pwd=$_POST['password'];
	
    include '../dbconfig.php';

    $sql="SELECT student_id from student where student_usn='4GE12CS041' and student_password='password'";
    $result= mysqli_query($conn,$sql);
    $row=  mysqli_fetch_array($result,MYSQLI_ASSOC);
    if($row['student_id']>0)
    {
            $eid=$row['student_id'];
            echo $eid;
    }
    else
    {
            echo "invalid";
    }
?>

