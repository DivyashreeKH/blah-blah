<?php 
     include("dbconfig.php");
    $bookid=$_GET['bookid'];
    $sql4 = "select * from book where book_id=$bookid";
    $result4=mysqli_query($conn, $sql4);
    //$row4=mysqli_fetch_array($result4, MYSQL_ASSOC);
     $row4 = $result4->fetch_assoc();
    $book_name=$row4['book_name'];
    $book_author=$row4['book_author'];
    $book_publisher=$row4['book_publisher'];
    $book_section=$row4['book_section'];
    $book_row=$row4['book_row'];
    $book_col=$row4['book_col'];
    $book_description=$row4['book_description'];
    
    //set it to writable location, a place for temp generated PNG files
    $PNG_TEMP_DIR = dirname(__FILE__).DIRECTORY_SEPARATOR.'books'.DIRECTORY_SEPARATOR;
    
    //html PNG location prefix
    $PNG_WEB_DIR = 'books/';

    include "qrlib.php";    
    
    //ofcourse we need rights to create temp dir
    if (!file_exists($PNG_TEMP_DIR))
        mkdir($PNG_TEMP_DIR);
    
    
    $filename = $PNG_TEMP_DIR."$bookid".'.png';
    
    $errorCorrectionLevel = 'H';
    $matrixPointSize = 6;
        QRcode::png($bookid, $filename, $errorCorrectionLevel, $matrixPointSize, 2);
        
    //display generated file
    echo "<html><body><h3><table border=1><th>Book Information</th>";
    echo '<tr><td align=center><img src="'.$PNG_WEB_DIR.basename($filename).'" /></td>';
    echo "<td>Book Name : $book_name <br> Book Author : $book_author";
    echo "<br>Book Publisher : $book_publisher<br>Section : $book_section";
    echo "<br>Row : $book_row<br>Column : $book_col";
    echo '</table><hr/><a href="welcome"><input type="submit" value="Home"></a></h3></body></html>';  