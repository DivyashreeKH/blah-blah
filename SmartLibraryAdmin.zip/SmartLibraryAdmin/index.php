<?php
session_start();
include("dbconfig.php");
if(isset($_SESSION['username']) && isset($_SESSION['password']))
{
    $_SESSION['username']=NULL;
    $_SESSION['password']=NULL;
}
else
{
}
?>
<html >
<head>
  <meta charset="UTF-8">
  <title>Smart Library Admin</title>
  <link rel="stylesheet" href="assets/css/style1.css">
</head>

<body>
  <hgroup>
  <h1>Admin Login</h1>
</hgroup>
<form action="" method="post">
  <div class="group">
    <input type="text" name="username"><span class="highlight"></span><span class="bar"></span>
    <label>Username</label>
  </div>
  <div class="group">
      <input type="password" name="password"><span class="highlight"></span><span class="bar"></span>
    <label>Password</label>
  </div>
  <input type="submit" name="submt" value="Login" class="button buttonBlue">
   <?php
          if(isset($_POST['username']) && isset ($_POST['password']))
          {
                $user=$_POST['username'];
                $pass=$_POST['password'];              
               
                $sql="select name,password from admin where name='$user' and password='$pass'";
                $result= mysqli_query($conn,$sql);
                $row=  mysqli_fetch_array($result,MYSQLI_ASSOC);
                $dbname=$row['name'];
                $dbpass=$row['password'];
                
                if($user==NULL || $pass==NULL)
                {
                    echo "<h4 style=\"color: red\">All fileds are mandatory\n</h4>";
                }
                else if($user!=$dbname && $pass!=$dbpass)
                {
                    echo "<h4 style=\"color: red\">Enter valid username and password\n</h4>";
                    
                } 
                else
                {
                    $_SESSION['username']=$user;
                    $_SESSION['password']=$pass;
                    echo '<META http-equiv="refresh" content="0;welcome">';
                }
          }
          else  
          {
          }
 ?>
</form>
    
<footer>
</footer>
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
  <script src="assets/js/index.js"></script>
</body>
</html>
