<?php
session_start();
if(isset($_SESSION['username']) && isset($_SESSION['password']))
{
    $user=$_SESSION['username'];
    $pwd=$_SESSION['password'];
}
else
{
  echo '<META http-equiv="refresh" content="0;logout">';
}
?>
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="apple-touch-icon" href="apple-touch-icon.png">

        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <!--        <link rel="stylesheet" href="assets/css/bootstrap-theme.min.css">-->


        <!--For Plugins external css-->
        <link rel="stylesheet" href="assets/css/plugins.css" />
        <link rel="stylesheet" href="assets/css/opensans-web-font.css" />
        <link rel="stylesheet" href="assets/css/montserrat-web-font.css" />

		<!--For font-awesome css-->
        <link rel="stylesheet" href="assets/css/font-awesome.min.css" />
<link rel="stylesheet" href="assets/css/style1.css">
        <!--Theme custom css -->
        <link rel="stylesheet" href="assets/css/style.css">

        <!--Theme Responsive css-->
        <link rel="stylesheet" href="assets/css/responsive.css" />

        <script src="assets/js/vendor/modernizr-2.8.3-respond-1.4.2.min.js"></script>
    </head>
    <body>
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
		
		<div class='preloader'><div class='loaded'>&nbsp;</div></div>
        <nav class="mainmenu navbar navbar-default navbar-fixed-top">
            <div class="container">
			
			<div class="row">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
					
					<div class="brand-bg">
                    <a class="navbar-brand" href="index"><img src="assets/images/logo2.png" alt="Smart Library" /></a>
					</div>
                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav pull-right">
                        <li><a href="welcome">Home</a></li>
                       <li><a href="addbooks">Add Books</a></li>
                        <li><a href="addlibrarian">Add Librarian</a></li>
                        <li class="active"><a href="addstudents">Add Students</a></li>  
                        <li><a href="viewstudents">View Students</a></li>  
                        <li><a href="viewbooks">View Books</a></li>  
                        <li><a href="logout">Logout</a></li>    
                    </ul>
                </div><!-- /.navbar-collapse -->
				</div>
				
            </div><!-- /.container-fluid -->
        </nav>

        <!--Home page style-->
        <header class="home-bg">
		<div class="overlay-img">
			<div class="container">
				<div class="row">
					<div class="col-md-6 col-sm-12 col-xs-12">
						<div class="header-details">
                                                    <h1 style="color : white">intelligence<br> is nothing without ambition<i class="fa fa-circle"></i></h1>
							<p>**********</p>							
						</div>
					</div>
					

				</div>
			</div>
		</div>	
        </header>

        <!-- Sections -->
        
		
		
		<section id="portfolio-area" class="sections">
            <div class="container">
                <!-- Example row of columns -->
                <div class="row">

                <form action="" method="post">
                    <div class="group">
    <span class="highlight"></span><span class="bar"></span>
    <label style="color: red">Add Student</label>
  </div>
  <div class="group">
    Student Name
    <input type="text" name="studentname" required><span class="highlight"></span><span class="bar"></span>
  </div>
  <div class="group">
    Student USN
      <input type="text" name="usn" required><span class="highlight"></span><span class="bar"></span>
  </div>
   <div class="group">
    Mobile Number
      <input type="text" name="phnonumber" required><span class="highlight"></span><span class="bar"></span>
  </div>
    <div class="group">
    Email Address
        <input type="email" name="email" required><span class="highlight"></span><span class="bar"></span>
  </div>
     <div class="group">
    Password
        <input type="password" name="password" required><span class="highlight"></span><span class="bar"></span>
      </div>     
    <div class="group">
    Re-Enter Password
        <input type="password" name="repassword" required><span class="highlight"></span><span class="bar"></span>
      </div>     
    <div class="group">
        semester
        <input type="number" min="1" max="8" step="1" name="sem" required><span class="highlight"></span><span class="bar"></span>
  </div>
  <input type="submit" name="submt" value="Add Studet" class="button buttonBlue">
  <?php
          if(isset($_POST['studentname']) && isset ($_POST['usn']) && isset ($_POST['phnonumber']) && isset ($_POST['email']) && isset ($_POST['password']) && isset ($_POST['repassword']) && isset ($_POST['sem']))
          {
                include './dbconfig.php';
                $studentname=$_POST['studentname'];
                $usn=$_POST['usn'];  
                $number=$_POST['phnonumber'];  
                $email=$_POST['email'];  
                $password=$_POST['password'];  
                $repassword=$_POST['repassword'];  
                $sem=$_POST['sem']; 
                $flag=0;
                
                $sql4 = "select student_usn from student";
                $result4 = $conn->query($sql4);
                if ($result4->num_rows > 0) 
                {
                    while($row4 = $result4->fetch_assoc()) 
                    {
                        if($row4['student_usn']==$usn)
                        {
                            $flag=1;
                        }
                        else
                        {
                            $flag=0;
                        }
                    }
                }
                if(empty($studentname) OR empty($usn) OR empty($number) OR empty($email) OR empty($password) OR empty($repassword) OR empty($sem))
                {
                    echo "<h4 style=\"color: red\">All Fields are mandatory\n</h4>";
                }
                else if($flag==1)
                {
                    echo '<script type="text/javascript">alert("Student already added")</script>';
                    echo '<META http-equiv="refresh" content="0;viewstudents">';
                }
                else if($password!=$repassword)
                {
                    echo "<h4 style=\"color: red\">Password Mismatch\n</h4>";
                }
                else if($sem>8)
                {
                    echo "<h4 style=\"color: red\">Semester must not be more than 8\n</h4>";
                }
                else
                {
                    
                    $sql1="INSERT INTO `student`(`student_id`, `student_usn`, `student_name`, `student_password`, `student_branch`, `student_sem`, `student_phone`, `student_email`) VALUES "
                            . "('','$usn','$studentname','$password','Computer Science','$sem','$number','$email')";
                    $result1= mysqli_query($conn,$sql1);
                    if($result1==1)
                    {
                        $sql4 = "select * from student";
                        $result4 = $conn->query($sql4);
                        if ($result4->num_rows > 0) 
                        {
                            while($row4 = $result4->fetch_assoc()) 
                            {
                                $stdid=$row4['student_id'];
                            }
                        }
                        echo '<script type="text/javascript">alert("Student Added Successfully")</script>';    
                        echo '<META http-equiv="refresh" content="0;generatestdqrcode?studentid='.$stdid.'">';
                        $studentname=null;
                        $usn=null;  
                        $number=null;  
                        $email=null;  
                        $password=null;  
                        $repassword=null;  
                        $branch=null; 
                        $sem=null;             
                    }
                    else
                    {
                        echo '<script type="text/javascript">alert("Server Error")</script>';
                    }
                }
                $studentname=null;
                $usn=null;  
                $number=null;  
                $email=null;  
                $password=null;  
                $repassword=null;  
                $branch=null; 
                $sem=null;           
          }
          else  
          {
          }
 ?>
  <h5><a href="viewstudents">View All Students</a></h5>
</form>
                  

                </div>
            </div> <!-- /container -->       
        </section>
		
		<div class="scroll-top">
		
			<div class="scrollup">
				<i class="fa fa-angle-double-up"></i>
			</div>
			
		</div>
	
        <!--Footer-->
        <footer>
            <div class="container">
			<hr>
            	<div class="row">
				
            		<div class="col-md-6 col-sm-6 col-xs-12">
						<div class="social-network">
							<a href="#"><i class="fa fa-twitter"></i></a>
							<a href="#"><i class="fa fa-instagram"></i></a>
							<a href="#"><i class="fa fa-facebook"></i></a>
							<a href="#"><i class="fa fa-google-plus"></i></a>
						</div>
					</div>
					
            		<div class="col-md-6 col-sm-6 col-xs-12">
						<div class="copyright">
							<p>Powered by <a target="_blank" href="http://innovantitsolutions.in/"> Innovant IT Solutions </a>2017. All rights reserved.</p>
						</div>
					</div>
					
            	</div>
            </div>
        </footer>


        <script src="assets/js/vendor/jquery-1.11.2.min.js"></script>
        <script src="assets/js/vendor/bootstrap.min.js"></script>

        <script src="assets/js/plugins.js"></script>
        <script src="assets/js/main.js"></script>
    </body>
</html>
