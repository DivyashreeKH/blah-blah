 <?php
        session_start(); 
        if(isset($_SESSION['username']) && isset($_SESSION['password']))
        {
            $user=$_SESSION['username'];
            $pwd=$_SESSION['password'];
            include("dbconfig.php");
            $id=$_GET["bookid"];
            $sql = "DELETE FROM `book` WHERE book_id='$id'";
            $result=mysqli_query($conn, $sql);
            if($result==1)
            {
                echo '<script type="text/javascript">alert("Book Deleted")</script>';
                echo '<META http-equiv="refresh" content="0;viewbooks">';
            }
            else 
            {
                echo "<h1>Error</h1>";
            }
        }
        else
        {
          echo '<META http-equiv="refresh" content="0;logout">';
        }
 ?>