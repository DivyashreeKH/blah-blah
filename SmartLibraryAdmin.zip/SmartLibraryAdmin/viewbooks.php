<?php
session_start();
if(isset($_SESSION['username']) && isset($_SESSION['password']))
{
    $user=$_SESSION['username'];
    $pwd=$_SESSION['password'];
    $count=1;
}
else
{
  echo '<META http-equiv="refresh" content="0;logout">';
}
?>
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="apple-touch-icon" href="apple-touch-icon.png">

        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <!--        <link rel="stylesheet" href="assets/css/bootstrap-theme.min.css">-->


        <!--For Plugins external css-->
        <link rel="stylesheet" href="assets/css/plugins.css" />
        <link rel="stylesheet" href="assets/css/opensans-web-font.css" />
        <link rel="stylesheet" href="assets/css/montserrat-web-font.css" />

		<!--For font-awesome css-->
        <link rel="stylesheet" href="assets/css/font-awesome.min.css" />
<link rel="stylesheet" href="assets/css/style1.css">
        <!--Theme custom css -->
        <link rel="stylesheet" href="assets/css/style.css">

        <!--Theme Responsive css-->
        <link rel="stylesheet" href="assets/css/responsive.css" />

        <script src="assets/js/vendor/modernizr-2.8.3-respond-1.4.2.min.js"></script>
    </head>
    <body>
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
		
		<div class='preloader'><div class='loaded'>&nbsp;</div></div>
        <nav class="mainmenu navbar navbar-default navbar-fixed-top">
            <div class="container">
			
			<div class="row">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
					
					<div class="brand-bg">
                    <a class="navbar-brand" href="index"><img src="assets/images/logo2.png" alt="Smart Library" /></a>
					</div>
                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav pull-right">
                        <li><a href="welcome">Home</a></li>
                       <li><a href="addbooks">Add Books</a></li>
                        <li><a href="addlibrarian">Add Librarian</a></li>
                        <li><a href="addstudents">Add Students</a></li>  
                        <li><a href="viewstudents">View Students</a></li>  
                        <li class="active"><a href="viewbooks">View Books</a></li>  
                        <li><a href="logout">Logout</a></li>    
                    </ul>
                </div><!-- /.navbar-collapse -->
				</div>
				
            </div><!-- /.container-fluid -->
        </nav>

        <!--Home page style-->
        <header class="home-bg">
		<div class="overlay-img">
			<div class="container">
				<div class="row">
					<div class="col-md-6 col-sm-12 col-xs-12">
						<div class="header-details">
                                                    <h1 style="color : white">intelligence<br> is nothing without ambition<i class="fa fa-circle"></i></h1>
							<p>**********</p>							
						</div>
					</div>
					

				</div>
			</div>
		</div>	
        </header>

        <!-- Sections -->
        
		
		
		<section id="portfolio-area" class="sections">
            <div class="container">
                <!-- Example row of columns -->
                <div class="row">
    <?php
        include './dbconfig.php';
        $sql = "SELECT * FROM `book`";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) 
        {
            echo "<br><table width=\"100%\" align=\"center\"><tr bgcolor=#49FFD8><td>ID</td><td>BOOK NAME</td><td>AUTHOR NAME</td><td>PUBLISHER NAME</td><td>BOOK SECTION</td><td>BOOK ROW</td><td>BOOK COLUMN</td><td>NO OF COPIES</td><td>TOTAL COPIES</td></tr>";
            while($row = $result->fetch_assoc()) 
            {
                $bookid=$row['book_id'];
                echo "<tr><td align=\"center\">".$count."</td><td align=\"center\">" .$row["book_name"]."</td><td align=\"center\">" .$row['book_author']."</td><td align=\"center\">" .$row["book_publisher"]."</td><td align=\"center\">" .$row["book_section"]."</td><td align=\"center\">" .$row["book_row"]."</td><td align=\"center\">" .$row["book_col"]."</td><td align=\"center\">" .$row["no_of_copies"]."</td><td align=\"center\">" .$row["max_copies"]."</td>
                <td align=\"center\"><a href=\"editbook?bookid=$bookid\"><img src=\"assets/images/edit.png\">Edit</a></td>
                <td align=\"center\"><a href=\"generateqrcode?bookid=$bookid\"><img src=\"assets/images/qr.png\">View</a></td>
                <td align=\"center\"><a href=\"deletebook.php?bookid=$bookid\"><img src=\"assets/images/delete.png\">Delete</a></td></tr>";
                $count++;
            }
            echo"</table>";
            $conn->close();

        }
        else
        {
            echo "<br><table align=\"center\"><td>  No Books to display <br/><br/>Click Here to <a href=\"addbooks\">Add Books</a></td>";
        }
    ?>
                </div>
            </div> <!-- /container -->       
        </section>
        <div class="scroll-top">
		
			<div class="scrollup">
				<i class="fa fa-angle-double-up"></i>
			</div>
			
		</div>
	
        <!--Footer-->
        <footer>
            <div class="container">
			<hr>
            	<div class="row">
				
            		<div class="col-md-6 col-sm-6 col-xs-12">
						<div class="social-network">
							<a href="#"><i class="fa fa-twitter"></i></a>
							<a href="#"><i class="fa fa-instagram"></i></a>
							<a href="#"><i class="fa fa-facebook"></i></a>
							<a href="#"><i class="fa fa-google-plus"></i></a>
						</div>
					</div>
					
            		<div class="col-md-6 col-sm-6 col-xs-12">
						<div class="copyright">
							<p>Powered by <a target="_blank" href="http://innovantitsolutions.in/"> Innovant IT Solutions </a>2017. All rights reserved.</p>
						</div>
					</div>
					
            	</div>
            </div>
        </footer>


        <script src="assets/js/vendor/jquery-1.11.2.min.js"></script>
        <script src="assets/js/vendor/bootstrap.min.js"></script>

        <script src="assets/js/plugins.js"></script>
        <script src="assets/js/main.js"></script>
    </body>
</html>
