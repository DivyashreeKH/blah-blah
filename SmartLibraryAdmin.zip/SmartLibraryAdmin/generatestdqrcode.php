<?php 
    include './dbconfig.php';
    $studentid=$_GET['studentid'];
    $sql4 = "select * from student where student_id=$studentid";
    $result4=mysqli_query($conn, $sql4);
   // $row4=mysqli_fetch_array($result4, MYSQL_ASSOC);
    $row4 = $result4->fetch_assoc();
    $usn=$row4['student_usn'];
    $student_name=$row4['student_name'];
    $student_password=$row4['student_password'];
    $student_branch=$row4['student_branch'];
    $student_sem=$row4['student_sem'];
    $student_phone=$row4['student_phone'];
    $student_email=$row4['student_email'];
    
    //set it to writable location, a place for temp generated PNG files
    $PNG_TEMP_DIR = dirname(__FILE__).DIRECTORY_SEPARATOR.'students'.DIRECTORY_SEPARATOR;
    
    //html PNG location prefix
    $PNG_WEB_DIR = 'students/';

    include "qrlib.php";    
    
    //ofcourse we need rights to create temp dir
    if (!file_exists($PNG_TEMP_DIR))
        mkdir($PNG_TEMP_DIR);
    
    
    $filename = $PNG_TEMP_DIR."$usn".'.png';
    
    $errorCorrectionLevel = 'H';
    $matrixPointSize = 4;
        QRcode::png($usn, $filename, $errorCorrectionLevel, $matrixPointSize, 2);
        
    //display generated file
    echo "<html><body><table border=1><th>Student Library Card</th>";
    echo '<tr><td align=center><img src="'.$PNG_WEB_DIR.basename($filename).'" /></td>';
    echo "<td>Student Name : $student_name <br> USN : $usn";
    echo "<br>Sem : $student_sem<br>Branch : $student_branch";
    echo "<br>Ph Number : $student_phone<br>Email Address : $student_email";
    echo '</table><hr/><a href="welcome"><input type="submit" value="Home"></a></body></html>';  
    